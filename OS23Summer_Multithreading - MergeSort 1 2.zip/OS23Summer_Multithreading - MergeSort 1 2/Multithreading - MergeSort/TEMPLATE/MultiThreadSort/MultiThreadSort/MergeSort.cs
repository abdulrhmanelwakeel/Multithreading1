using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Threading;


namespace MultiThreadSort
{
    public class MergeSort
    {
        #region Helper Functions [TASK 1]
        public static object Params2Object(int[] A, int s, int e, int m, int node_idx)
        {
            #region [TASK 1.1]
            //TODO: Encapsulate the given params into a single ArrayList object, then return it
            //return null;
            ArrayList parameters = new ArrayList();
            parameters.Add(A);
            parameters.Add(s);
            parameters.Add(e);
            parameters.Add(m);
            parameters.Add(node_idx);

            return parameters;

            #endregion
        }

        public static void Object2Params(object parameters, ref int[] A, ref int s, ref int e, ref int m, ref int node_idx)
        {
            #region [TASK 1.2]
            //TODO: Extract ALL params from the given ArrayList object "parameters", then store each of them in the corresponding "ref" variable 
            ArrayList paramList = (ArrayList)parameters;
            A = (int[])paramList[0];
            s = (int)paramList[1];
            e = (int)paramList[2];
            m = (int)paramList[3];
            node_idx = (int)paramList[4];
            #endregion
        }
        #endregion

        //DO NOT CHANGE THIS CODE
        #region Sequential Sort 

        public static void Sort(int[] array)
        {
            MSort(array, 1, array.Length);
        }

        private static void MSort(int[] A, int s, int e)
        {
            if (s >= e)
            {
                return;
            }

            int m = (s + e) / 2;

            MSort(A, s, m);

            MSort(A, m + 1, e);

            Merge(A, s, m, e);
        }

        private static void Merge(int[] A, int s, int m, int e)
        {
            int leftCapacity = m - s + 1;

            int rightCapacity = e - m;

            int leftIndex = 0;

            int rightIndex = 0;

            int[] Left = new int[leftCapacity];

            int[] Right = new int[rightCapacity];

            for (int i = 0; i < Left.Length; i++)
            {
                Left[i] = A[s + i - 1];
            }

            for (int j = 0; j < Right.Length; j++)
            {
                Right[j] = A[m + j];
            }

            for (int k = s; k <= e; k++)
            {
                if (leftIndex < leftCapacity && rightIndex < rightCapacity)
                {
                    if (Left[leftIndex] < Right[rightIndex])
                    {
                        A[k - 1] = Left[leftIndex++];
                    }
                    else
                    {
                        A[k - 1] = Right[rightIndex++];
                    }
                }
                else if (leftIndex < leftCapacity)
                {
                    A[k - 1] = Left[leftIndex++];
                }
                else
                {
                    A[k - 1] = Right[rightIndex++];
                }
            }
        }
        #endregion

        //TODO: Change this function to be MULTITHREADED
        //HINT: Remember to handle any dependency and/or critical section issues

        #region Multithreaded Sort [REMAINING TASKS]
        static int NumMergeSortThreads;

        #region Semaphores
        static Semaphore mergeSemaphore = new Semaphore(0); // Initialize to 0
        static Semaphore mergeSemaphoreSort1 = new Semaphore(0); // Initialize to 0
        static Semaphore mergeSemaphoreSort2 = new Semaphore(0); // Initialize to 0
        #endregion

        #region Threads
        static Thread mergeThread1;
        static Thread mergeThread2;
        static Thread mergeThread3;
        static Thread mergeSortThread1;
        static Thread mergeSortThread2;
        static Thread mergeSortThread3;
        static Thread mergeSortThread4;
        #endregion

        #region Sort Function
        public static void SortMT(int[] array)
        {
            int s = 1;
            int e = array.Length;
            int m = (s + e) / 2;
            int node_idx = 0;
            object parameters = Params2Object(array, s, e, m, node_idx);


            //NumMergeSortThreads = 2;                //TASK 2
            NumMergeSortThreads = 4;   //TASK 3

            #region [TASK 2]
            if (NumMergeSortThreads == 2)       //TASK 2
            {
                mergeSortThread1 = new Thread(MSortMT);
                mergeSortThread2 = new Thread(MSortMT);
                mergeThread1 = new Thread(MergeMT);

                int half = array.Length / 2;


                mergeSortThread1.Start(Params2Object(array, 1, half, half / 2, 0));
                mergeSortThread2.Start(Params2Object(array, half + 1, array.Length, half + (array.Length - half) / 2, 1));

                mergeThread1.Start(parameters);

                mergeThread1.Join();
            }
            #endregion

            #region [TASK 3]
            else if (NumMergeSortThreads == 4)   //TASK 3
            {
                mergeSortThread1 = new Thread(MSortMT);
                mergeSortThread2 = new Thread(MSortMT);
                mergeSortThread3 = new Thread(MSortMT);
                mergeSortThread4 = new Thread(MSortMT);
                mergeThread1 = new Thread(MergeMT);
                mergeThread2 = new Thread(MergeMT);
                mergeThread3 = new Thread(MergeMT);

                int quarter1 = array.Length / 4;
                int quarter2 = array.Length / 2;
                int quarter3 = 3 * array.Length / 4;

                mergeSortThread1.Start(Params2Object(array, 1, quarter1, (1 + quarter1) / 2, 0));
                mergeSortThread2.Start(Params2Object(array, quarter1 + 1, quarter2, (quarter1 + quarter2 + 1) / 2, 1));
                mergeSortThread3.Start(Params2Object(array, quarter2 + 1, quarter3, (quarter2 + quarter3 + 1) / 2, 2));
                mergeSortThread4.Start(Params2Object(array, quarter3 + 1, array.Length, (quarter3 + array.Length + 1) / 2, 3));

                mergeThread1.Start(Params2Object(array, 1, quarter2, (1 + quarter2) >> 1, 0));
                mergeThread2.Start(Params2Object(array, quarter2 + 1, array.Length, (quarter2 + 1 + array.Length) >> 1, 1));
                mergeThread3.Start(Params2Object(array, 1, array.Length, (1 + array.Length) >> 1, 2));
                //mergeThread3.Join();
            }

            #endregion


        }

        private static void MSortMT(object parameters)
        {
            #region Extract params from the given object 
            int[] A = null;
            int s = 0;
            int e = 0;
            int m = 0;
            int node_idx = 0;
            Object2Params(parameters, ref A, ref s, ref e, ref m, ref node_idx);
            #endregion

            MSort(A, s, e);
            #region [TASK 2]
            if (NumMergeSortThreads == 2)
                mergeSemaphoreSort1.Signal();
            #endregion

            #region [TASK 3]
            if (NumMergeSortThreads == 4)
                if (node_idx < 2)
                    mergeSemaphoreSort1.Signal();
                else
                    mergeSemaphoreSort2.Signal();
            #endregion

        }

        private static void MergeMT(object parameters)
        {
            #region Extract params from the given object
            int[] A = null;
            int s = 0;
            int e = 0;
            int m = 0;
            int node_idx = 0;
            Object2Params(parameters, ref A, ref s, ref e, ref m, ref node_idx);
            #endregion

            #region [TASK 2]
            if (NumMergeSortThreads == 2)       //TASK 2
            {
                // Use semaphores to handle any dependency or critical section
                mergeSemaphoreSort1.Wait(); // Wait for sorting threads to complete
                mergeSemaphoreSort1.Wait(); // Wait for sorting threads to complete
                Merge(A, s, m, e);

                // Signal that merging is done
                //mergeSemaphore.Signal(); // Release instead of using mergeSortSemaphore

            }
            #endregion

            #region [TASK 3]
            else if (NumMergeSortThreads == 4)   //TASK 3
            {
                //TODO: Use semaphores to handle any dependency or critical section
                // Use semaphores to handle any dependency or critical section
                if (node_idx == 0) // Merge Thread 1 and Merge Thread 3
                {
                    mergeSemaphoreSort1.Wait();
                    mergeSemaphoreSort1.Wait();
                    Merge(A, s, m, e);
                    mergeSemaphore.Signal();
                }
                if (node_idx == 1) // Merge Thread 1 and Merge Thread 3
                {
                    mergeSemaphoreSort2.Wait();
                    mergeSemaphoreSort2.Wait();
                    Merge(A, s, m, e);
                    mergeSemaphore.Signal();
                }
                else if (node_idx == 2) // Merge Thread 2
                {
                    mergeSemaphore.Wait();
                    mergeSemaphore.Wait();
                    Merge(A, s, m, e);
                }
            }

            #endregion
        }
        #endregion

        #endregion
        

    }
}